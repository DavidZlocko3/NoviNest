﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace IspitProgram
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnDodajIP_Click(object sender, EventArgs e)
        {
            string ipText = textBoxDodajIP.Text.Trim();

            if (IPAddress.TryParse(ipText, out _))
            {
                if (!listBoxIPs.Items.Contains(ipText))
                {
                    listBoxIPs.Items.Add(ipText);
                    textBoxDodajIP.Clear();
                }
                else
                {
                    MessageBox.Show("IP adresa već postoji na listi.", "Upozorenje", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Neispravan format IP adrese.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private async void btnStartScan_Click(object sender, EventArgs e)
        {
            listBoxResults.Items.Clear();

            if (!int.TryParse(txtPortStart.Text, out int portStart) ||
                !int.TryParse(txtPortEnd.Text, out int portEnd) ||
                portStart < 1 || portEnd > 65535 || portEnd < portStart)
            {
                MessageBox.Show("Unesi ispravan port range.");
                return;
            }

            bool isTcp = radioTCP.Checked;

            string messageToSend = "y";
            string expectedResponse = "x";

            foreach (string ipString in listBoxIPs.Items)
            {
                if (!IPAddress.TryParse(ipString, out IPAddress ip))
                {
                    listBoxResults.Items.Add($"Nevažeći IP: {ipString}");
                    continue;
                }

                for (int port = portStart; port <= portEnd; port++)
                {
                    if (isTcp)
                    {
                        await Task.Run(() => ScanTcp(ipString, port, messageToSend, expectedResponse));
                    }
                    else
                    {
                        await Task.Run(() => ScanUdp(ipString, port, messageToSend, expectedResponse));
                    }
                }
            }
        }
        private void ScanTcp(string ip, int port, string message, string expectedResponse)
        {
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    client.ReceiveTimeout = 2000;
                    client.SendTimeout = 2000;
                    client.Connect(ip, port);

                    NetworkStream stream = client.GetStream();
                    byte[] buffer = Encoding.ASCII.GetBytes(message);
                    stream.Write(buffer, 0, buffer.Length);

                    byte[] responseBuffer = new byte[256];
                    int bytesRead = stream.Read(responseBuffer, 0, responseBuffer.Length);
                    string response = Encoding.ASCII.GetString(responseBuffer, 0, bytesRead);

                    if (response.Trim() == expectedResponse)
                    {
                        Invoke(new Action(() =>
                        {
                            listBoxResults.Items.Add($"TCP OK: {ip}:{port}");
                        }));
                    }
                }
            }
            catch { 
            }
        }
        private void ScanUdp(string ip, int port, string message, string expectedResponse)
        {
            try
            {
                using (UdpClient sender = new UdpClient())
                using (UdpClient receiver = new UdpClient(port + 1)) 
                {
                    receiver.Client.ReceiveTimeout = 2000;

                    IPEndPoint target = new IPEndPoint(IPAddress.Parse(ip), port);
                    byte[] data = Encoding.ASCII.GetBytes(message);
                    sender.Send(data, data.Length, target);

                    IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);
                    byte[] response = receiver.Receive(ref remoteEP);
                    string responseStr = Encoding.ASCII.GetString(response);

                    if (responseStr.Trim() == expectedResponse)
                    {
                        Invoke(new Action(() =>
                        {
                            listBoxResults.Items.Add($"UDP OK: {ip}:{port}");
                        }));
                    }
                }
            }
            catch { }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
