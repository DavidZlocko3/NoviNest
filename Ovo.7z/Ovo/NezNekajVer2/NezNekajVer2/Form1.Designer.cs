﻿namespace NezNekajVer2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            lblUserCount = new Label();
            label4 = new Label();
            lblRoomName = new Label();
            label5 = new Label();
            txtUsername = new TextBox();
            txtIP = new TextBox();
            txtPort = new TextBox();
            txtMessage = new TextBox();
            btnConnect = new Button();
            btnDisconnect = new Button();
            listBoxUsers = new ListBox();
            listBoxChat = new ListBox();
            btnSend = new Button();
            btnSendImage = new Button();
            pictureBoxImage = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(26, 38);
            label1.Name = "label1";
            label1.Size = new Size(118, 25);
            label1.TabIndex = 0;
            label1.Text = "Ime Korisnika";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(26, 87);
            label2.Name = "label2";
            label2.Size = new Size(121, 25);
            label2.TabIndex = 1;
            label2.Text = "IP Chatrooma";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(26, 134);
            label3.Name = "label3";
            label3.Size = new Size(138, 25);
            label3.TabIndex = 2;
            label3.Text = "Port Chatrooma";
            // 
            // lblUserCount
            // 
            lblUserCount.AutoSize = true;
            lblUserCount.Location = new Point(26, 452);
            lblUserCount.Name = "lblUserCount";
            lblUserCount.Size = new Size(59, 25);
            lblUserCount.TabIndex = 3;
            lblUserCount.Text = "label3";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(526, 38);
            label4.Name = "label4";
            label4.Size = new Size(125, 25);
            label4.TabIndex = 4;
            label4.Text = "Napiši Poruku:";
            // 
            // lblRoomName
            // 
            lblRoomName.AutoSize = true;
            lblRoomName.Location = new Point(974, 67);
            lblRoomName.Name = "lblRoomName";
            lblRoomName.Size = new Size(59, 25);
            lblRoomName.TabIndex = 5;
            lblRoomName.Text = "label3";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 26F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(974, 2);
            label5.Name = "label5";
            label5.Size = new Size(415, 70);
            label5.TabIndex = 6;
            label5.Text = "Chatroom Klijent";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(165, 38);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(252, 31);
            txtUsername.TabIndex = 7;
            // 
            // txtIP
            // 
            txtIP.Location = new Point(165, 84);
            txtIP.Name = "txtIP";
            txtIP.Size = new Size(252, 31);
            txtIP.TabIndex = 8;
            // 
            // txtPort
            // 
            txtPort.Location = new Point(165, 131);
            txtPort.Name = "txtPort";
            txtPort.Size = new Size(252, 31);
            txtPort.TabIndex = 9;
            // 
            // txtMessage
            // 
            txtMessage.Location = new Point(526, 84);
            txtMessage.Multiline = true;
            txtMessage.Name = "txtMessage";
            txtMessage.Size = new Size(385, 73);
            txtMessage.TabIndex = 10;
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(26, 186);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(247, 97);
            btnConnect.TabIndex = 11;
            btnConnect.Text = "Spoji Se Na Chatroom";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // btnDisconnect
            // 
            btnDisconnect.Location = new Point(26, 304);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(247, 90);
            btnDisconnect.TabIndex = 12;
            btnDisconnect.Text = "Odspoji Se Is Chatrooma";
            btnDisconnect.UseVisualStyleBackColor = true;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // listBoxUsers
            // 
            listBoxUsers.FormattingEnabled = true;
            listBoxUsers.ItemHeight = 25;
            listBoxUsers.Location = new Point(26, 493);
            listBoxUsers.Name = "listBoxUsers";
            listBoxUsers.Size = new Size(298, 279);
            listBoxUsers.TabIndex = 13;
            // 
            // listBoxChat
            // 
            listBoxChat.FormattingEnabled = true;
            listBoxChat.ItemHeight = 25;
            listBoxChat.Location = new Point(974, 105);
            listBoxChat.Name = "listBoxChat";
            listBoxChat.Size = new Size(433, 679);
            listBoxChat.TabIndex = 14;
            // 
            // btnSend
            // 
            btnSend.Location = new Point(526, 175);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(385, 64);
            btnSend.TabIndex = 15;
            btnSend.Text = "Posalji Poruku";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSend_Click;
            // 
            // btnSendImage
            // 
            btnSendImage.Location = new Point(526, 255);
            btnSendImage.Name = "btnSendImage";
            btnSendImage.Size = new Size(385, 64);
            btnSendImage.TabIndex = 16;
            btnSendImage.Text = "Posalji Sliku";
            btnSendImage.UseVisualStyleBackColor = true;
            btnSendImage.Click += btnSendImage_Click;
            // 
            // pictureBoxImage
            // 
            pictureBoxImage.Location = new Point(526, 349);
            pictureBoxImage.Name = "pictureBoxImage";
            pictureBoxImage.Size = new Size(402, 434);
            pictureBoxImage.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxImage.TabIndex = 17;
            pictureBoxImage.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1450, 795);
            Controls.Add(pictureBoxImage);
            Controls.Add(btnSendImage);
            Controls.Add(btnSend);
            Controls.Add(listBoxChat);
            Controls.Add(listBoxUsers);
            Controls.Add(btnDisconnect);
            Controls.Add(btnConnect);
            Controls.Add(txtMessage);
            Controls.Add(txtPort);
            Controls.Add(txtIP);
            Controls.Add(txtUsername);
            Controls.Add(label5);
            Controls.Add(lblRoomName);
            Controls.Add(label4);
            Controls.Add(lblUserCount);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label lblUserCount;
        private Label label4;
        private Label lblRoomName;
        private Label label5;
        private TextBox txtUsername;
        private TextBox txtIP;
        private TextBox txtPort;
        private TextBox txtMessage;
        private Button btnConnect;
        private Button btnDisconnect;
        private ListBox listBoxUsers;
        private ListBox listBoxChat;
        private Button btnSend;
        private Button btnSendImage;
        private PictureBox pictureBoxImage;
    }
}
