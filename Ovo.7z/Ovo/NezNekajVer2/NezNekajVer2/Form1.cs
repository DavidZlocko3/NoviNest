using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;



namespace NezNekajVer2
{
    public partial class Form1 : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        private string username;
        public Form1()
        {
            InitializeComponent();
        }
        private void btnConnect_Click(object sender, EventArgs e)
        {
            username = txtUsername.Text.Trim();
            string ip = txtIP.Text.Trim();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(ip) || !int.TryParse(txtPort.Text.Trim(), out int port))
            {
                MessageBox.Show("Unesite ispravne podatke.");
                return;
            }

            try
            {
                client = new TcpClient();
                client.Connect(ip, port);
                stream = client.GetStream();

                byte[] nameData = Encoding.UTF8.GetBytes(username);
                stream.Write(nameData, 0, nameData.Length);

                Thread receiveThread = new Thread(ReceiveMessages);
                receiveThread.IsBackground = true;
                receiveThread.Start();

                btnConnect.Enabled = false;
                txtUsername.Enabled = false;
                txtIP.Enabled = false;
                txtPort.Enabled = false;
                btnDisconnect.Enabled = true;
                btnSend.Enabled = true;
                txtMessage.Enabled = true;
                btnSendImage.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gre�ka pri povezivanju: {ex.Message}");
            }
        }

        private void ReceiveMessages()
        {
            using StreamReader reader = new StreamReader(stream, Encoding.UTF8);
            while (true)
            {
                try
                {
                    string line = reader.ReadLine();
                    if (line == null) break;

                    if (line.StartsWith("__IMG:"))
                    {
                        string base64 = line.Substring(6);
                        byte[] imgBytes = Convert.FromBase64String(base64);

                        using MemoryStream ms = new MemoryStream(imgBytes);
                        Image img = Image.FromStream(ms);
                        Invoke(new Action(() =>
                        {
                            pictureBoxImage.Image = img;
                        }));
                    }
                    else if (line.StartsWith("ROOM|"))
                    {
                        string room = line.Substring(5);
                        Invoke(new Action(() => lblRoomName.Text = $"Chatroom: {room}"));
                    }
                    else if (line.StartsWith("[USERS]:"))
                    {
                        string[] users = line.Substring(8).Split(',');
                        Invoke(new Action(() =>
                        {
                            listBoxUsers.Items.Clear();
                            foreach (var user in users)
                                listBoxUsers.Items.Add(user);
                        }));
                    }
                    else if (line.StartsWith("__SETBG:"))
                    {
                        int argb = int.Parse(line.Substring(8));
                        Color newColor = Color.FromArgb(argb);
                        Invoke(new Action(() => listBoxChat.BackColor = newColor));
                    }
                    else
                    {
                        Invoke(new Action(() => listBoxChat.Items.Add(line)));
                    }
                }
                catch
                {
                    break;
                }
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string messageText = txtMessage.Text.Trim();
            if (string.IsNullOrEmpty(messageText)) return;

            string fullMessage = $"[{DateTime.Now:HH:mm}] {username}: {messageText}\n";
            byte[] data = Encoding.UTF8.GetBytes(fullMessage);
            stream.Write(data, 0, data.Length);
            txtMessage.Clear();
        }

        private void btnSendImage_Click(object sender, EventArgs e)
        {
            using OpenFileDialog ofd = new OpenFileDialog()
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp"
            };
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                using Bitmap original = new Bitmap(ofd.FileName);
                Bitmap resized = ResizeImage(original, 300, 300);

                using MemoryStream ms = new MemoryStream();
                resized.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                byte[] imgBytes = ms.ToArray();
                string base64 = Convert.ToBase64String(imgBytes);

                string message = "__IMG:" + base64 + "\n";
                byte[] data = Encoding.UTF8.GetBytes(message);
                stream.Write(data, 0, data.Length);
            }
        }

        private Bitmap ResizeImage(Image image, int maxWidth, int maxHeight)
        {
            float scale = Math.Min((float)maxWidth / image.Width, (float)maxHeight / image.Height);
            int newWidth = (int)(image.Width * scale);
            int newHeight = (int)(image.Height * scale);

            Bitmap resized = new Bitmap(newWidth, newHeight);
            using (Graphics g = Graphics.FromImage(resized))
            {
                g.DrawImage(image, 0, 0, newWidth, newHeight);
            }

            return resized;
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            Disconnect();
        }

        private void Disconnect()
        {
            try
            {
                stream?.Close();
                client?.Close();
            }
            catch { }

            Invoke(new Action(() =>
            {
                listBoxChat.Items.Add("Odspojen si sa servera.");
                btnConnect.Enabled = true;
                btnDisconnect.Enabled = false;
                btnSend.Enabled = false;
                btnSendImage.Enabled = false;
                txtMessage.Enabled = false;
            }));
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Disconnect();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
