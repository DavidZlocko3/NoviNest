using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Windows.Forms;



namespace SlikeKlijent
{
    public partial class Form1 : Form
    {
        private string selectedImagePath = "";
        public Form1()
        {
            InitializeComponent();
        }
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                selectedImagePath = ofd.FileName;
                txtFilePath.Text = selectedImagePath;
            }
        }
        private void btnSendImage_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectedImagePath))
            {
                MessageBox.Show("Odaberite sliku prvo.");
                return;
            }

            try
            {
                using TcpClient client = new TcpClient("127.0.0.1", 5000);
                using NetworkStream stream = client.GetStream();
                using FileStream fs = new FileStream(selectedImagePath, FileMode.Open, FileAccess.Read);

                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fs.Read(buffer, 0, buffer.Length)) > 0)
                {
                    stream.Write(buffer, 0, bytesRead);
                }

                MessageBox.Show("Slika poslana!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gre�ka: {ex.Message}");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
