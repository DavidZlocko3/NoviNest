﻿namespace SlikeKlijent
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSendImage = new Button();
            txtFilePath = new TextBox();
            btnBrowse = new Button();
            openFileDialog1 = new OpenFileDialog();
            SuspendLayout();
            // 
            // btnSendImage
            // 
            btnSendImage.Location = new Point(87, 311);
            btnSendImage.Name = "btnSendImage";
            btnSendImage.Size = new Size(255, 113);
            btnSendImage.TabIndex = 0;
            btnSendImage.Text = "Pošalji sliku";
            btnSendImage.UseVisualStyleBackColor = true;
            btnSendImage.Click += btnSendImage_Click;
            // 
            // txtFilePath
            // 
            txtFilePath.Location = new Point(80, 229);
            txtFilePath.Name = "txtFilePath";
            txtFilePath.Size = new Size(262, 31);
            txtFilePath.TabIndex = 1;
            // 
            // btnBrowse
            // 
            btnBrowse.Location = new Point(102, 72);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(255, 113);
            btnBrowse.TabIndex = 2;
            btnBrowse.Text = "Pregledaj";
            btnBrowse.UseVisualStyleBackColor = true;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1507, 792);
            Controls.Add(btnBrowse);
            Controls.Add(txtFilePath);
            Controls.Add(btnSendImage);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSendImage;
        private TextBox txtFilePath;
        private Button btnBrowse;
        private OpenFileDialog openFileDialog1;
    }
}
