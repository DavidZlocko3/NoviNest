﻿namespace Aplikacija_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtUsername = new TextBox();
            txtIP = new TextBox();
            txtPort = new TextBox();
            txtMessage = new TextBox();
            listBoxChat = new ListBox();
            lblRoomName = new Label();
            btnConnect = new Button();
            btnSend = new Button();
            btnDisconnect = new Button();
            lblUserCount = new Label();
            listBoxUsers = new ListBox();
            btnSendImage = new Button();
            pictureBoxImage = new PictureBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 63);
            label1.Name = "label1";
            label1.Size = new Size(234, 25);
            label1.TabIndex = 0;
            label1.Text = "Unesi IP Adresu Chatrooma:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 19);
            label2.Name = "label2";
            label2.Size = new Size(170, 25);
            label2.TabIndex = 1;
            label2.Text = "Unesi Ime Korisnika:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 109);
            label3.Name = "label3";
            label3.Size = new Size(190, 25);
            label3.TabIndex = 2;
            label3.Text = "Unesi Port Chatrooma:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(33, 253);
            label4.Name = "label4";
            label4.Size = new Size(119, 25);
            label4.TabIndex = 3;
            label4.Text = "Unesi Poruku:";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(194, 19);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(249, 31);
            txtUsername.TabIndex = 4;
            // 
            // txtIP
            // 
            txtIP.Location = new Point(258, 63);
            txtIP.Name = "txtIP";
            txtIP.Size = new Size(185, 31);
            txtIP.TabIndex = 5;
            // 
            // txtPort
            // 
            txtPort.Location = new Point(214, 109);
            txtPort.Name = "txtPort";
            txtPort.Size = new Size(229, 31);
            txtPort.TabIndex = 6;
            // 
            // txtMessage
            // 
            txtMessage.Location = new Point(33, 291);
            txtMessage.Multiline = true;
            txtMessage.Name = "txtMessage";
            txtMessage.Size = new Size(410, 101);
            txtMessage.TabIndex = 7;
            // 
            // listBoxChat
            // 
            listBoxChat.FormattingEnabled = true;
            listBoxChat.ItemHeight = 25;
            listBoxChat.Location = new Point(682, 287);
            listBoxChat.Name = "listBoxChat";
            listBoxChat.Size = new Size(558, 429);
            listBoxChat.TabIndex = 8;
            // 
            // lblRoomName
            // 
            lblRoomName.AutoSize = true;
            lblRoomName.Location = new Point(682, 240);
            lblRoomName.Name = "lblRoomName";
            lblRoomName.Size = new Size(52, 25);
            lblRoomName.TabIndex = 9;
            lblRoomName.Text = "Chat:";
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(508, 19);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(309, 121);
            btnConnect.TabIndex = 10;
            btnConnect.Text = "Spoji Se Na Chatroom";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // btnSend
            // 
            btnSend.Location = new Point(297, 225);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(146, 55);
            btnSend.TabIndex = 11;
            btnSend.Text = "Posalji";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSend_Click;
            // 
            // btnDisconnect
            // 
            btnDisconnect.Enabled = false;
            btnDisconnect.Location = new Point(863, 19);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(309, 121);
            btnDisconnect.TabIndex = 12;
            btnDisconnect.Text = "Izadi Iz Chatrooma";
            btnDisconnect.UseVisualStyleBackColor = true;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // lblUserCount
            // 
            lblUserCount.AutoSize = true;
            lblUserCount.Location = new Point(54, 461);
            lblUserCount.Name = "lblUserCount";
            lblUserCount.Size = new Size(102, 25);
            lblUserCount.TabIndex = 13;
            lblUserCount.Text = "Korisnika: 0";
            // 
            // listBoxUsers
            // 
            listBoxUsers.FormattingEnabled = true;
            listBoxUsers.ItemHeight = 25;
            listBoxUsers.Location = new Point(54, 502);
            listBoxUsers.Name = "listBoxUsers";
            listBoxUsers.Size = new Size(336, 229);
            listBoxUsers.TabIndex = 14;
            // 
            // btnSendImage
            // 
            btnSendImage.Location = new Point(476, 291);
            btnSendImage.Name = "btnSendImage";
            btnSendImage.Size = new Size(158, 101);
            btnSendImage.TabIndex = 15;
            btnSendImage.Text = "Posalji Sliku";
            btnSendImage.UseVisualStyleBackColor = true;
            btnSendImage.Click += btnSendImage_Click;
            // 
            // pictureBoxImage
            // 
            pictureBoxImage.Location = new Point(428, 500);
            pictureBoxImage.Name = "pictureBoxImage";
            pictureBoxImage.Size = new Size(218, 231);
            pictureBoxImage.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxImage.TabIndex = 16;
            pictureBoxImage.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(416, 460);
            label5.Name = "label5";
            label5.Size = new Size(187, 25);
            label5.TabIndex = 17;
            label5.Text = "Zadnja Primljena Slika:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1293, 762);
            Controls.Add(label5);
            Controls.Add(pictureBoxImage);
            Controls.Add(btnSendImage);
            Controls.Add(listBoxUsers);
            Controls.Add(lblUserCount);
            Controls.Add(btnDisconnect);
            Controls.Add(btnSend);
            Controls.Add(btnConnect);
            Controls.Add(lblRoomName);
            Controls.Add(listBoxChat);
            Controls.Add(txtMessage);
            Controls.Add(txtPort);
            Controls.Add(txtIP);
            Controls.Add(txtUsername);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtUsername;
        private TextBox txtIP;
        private TextBox txtPort;
        private TextBox txtMessage;
        private ListBox listBoxChat;
        private Label lblRoomName;
        private Button btnConnect;
        private Button btnSend;
        private Button btnDisconnect;
        private Label lblUserCount;
        private ListBox listBoxUsers;
        private Button btnSendImage;
        private PictureBox pictureBoxImage;
        private Label label5;
    }
}
