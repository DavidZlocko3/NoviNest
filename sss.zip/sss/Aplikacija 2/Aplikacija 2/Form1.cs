using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;


namespace Aplikacija_2
{
    public partial class Form1 : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        private string username;
        public Form1()
        {
            InitializeComponent();
        }
        private void btnConnect_Click(object sender, EventArgs e)
        {
            username = txtUsername.Text.Trim();
            string ip = txtIP.Text.Trim();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(ip) || !int.TryParse(txtPort.Text.Trim(), out int port))
            {
                MessageBox.Show("Unesite ispravne podatke.");
                return;
            }

            try
            {
                client = new TcpClient();
                client.Connect(ip, port);
                stream = client.GetStream();

                byte[] nameData = Encoding.UTF8.GetBytes(username);
                stream.Write(nameData, 0, nameData.Length);

                Thread receiveThread = new Thread(ReceiveMessages);
                receiveThread.IsBackground = true;
                receiveThread.Start();

                btnConnect.Enabled = false;
                txtUsername.Enabled = false;
                txtIP.Enabled = false;
                txtPort.Enabled = false;
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;
                btnSend.Enabled = true;
                txtMessage.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gre�ka pri povezivanju: {ex.Message}");
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string messageText = txtMessage.Text.Trim();
            if (string.IsNullOrEmpty(messageText)) return;

            string fullMessage = $"[{DateTime.Now:HH:mm}] {username}: {messageText}";
            byte[] data = Encoding.UTF8.GetBytes(fullMessage);
            stream.Write(data, 0, data.Length);
            txtMessage.Clear();
        }

        private void ReceiveMessages()
        {
            byte[] buffer = new byte[1024];
            while (true)
            {
                try
                {
                    int bytes = stream.Read(buffer, 0, buffer.Length);
                    if (bytes == 0) break;

                    string message = Encoding.UTF8.GetString(buffer, 0, bytes);

                    if (message.StartsWith("ROOM|"))
                    {
                        string room = message.Substring(5);
                        Invoke(new Action(() => lblRoomName.Text = $"Chatroom: {room}"));
                    }
                    else if (message.StartsWith("[USERS]:"))
                    {
                        string[] users = message.Substring(8).Split(',');
                        Invoke(new Action(() =>
                        {
                            listBoxUsers.Items.Clear();
                            foreach (var user in users)
                            {
                                listBoxUsers.Items.Add(user);
                            }
                            lblUserCount.Text = $"Korisnika: {users.Length}";
                        }));
                    }
                    else if (message.StartsWith("__SETBG:"))
                    {
                        int argb = int.Parse(message.Substring(8));
                        Color newColor = Color.FromArgb(argb);
                        Invoke(new Action(() => listBoxChat.BackColor = newColor));
                    }
                    else if (message.StartsWith("__IMG:"))
                    {
                        string base64 = message.Substring(6).Trim();
                        byte[] imgBytes = Convert.FromBase64String(base64);

                        using (MemoryStream ms = new MemoryStream(imgBytes))
                        {
                            Image img = Image.FromStream(ms);
                            Invoke(new Action(() =>
                            {
                                pictureBoxImage.Image = img;
                            }));
                        }
                    }
                    else
                    {
                        Invoke(new Action(() => listBoxChat.Items.Add(message)));
                    }
                }
                catch { break; }
            }
        }

        private void Disconnect()
        {
            try
            {
                if (stream != null)
                {
                    string goodbyeMessage = $"{username} je napustio sobu.";
                    byte[] data = Encoding.UTF8.GetBytes(goodbyeMessage);
                    stream.Write(data, 0, data.Length);
                }

                stream?.Close();
                client?.Close();
            }
            catch { }

            Invoke(new Action(() =>
            {
                btnConnect.Enabled = true;
                btnDisconnect.Enabled = false;
                txtMessage.Enabled = false;
                btnSend.Enabled = false;
                listBoxChat.Items.Add("Odspojen si sa servera.");
            }));
        }
        private void btnSendImage_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    using (Bitmap original = new Bitmap(ofd.FileName))
                    {
                        Bitmap resized = ResizeImage(original, 300, 300);

                        using (MemoryStream ms = new MemoryStream())
                        {
                            resized.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                            byte[] imgBytes = ms.ToArray();
                            string base64 = Convert.ToBase64String(imgBytes);
                            string message = "__IMG:" + base64 + "\n"; 
                            byte[] data = Encoding.UTF8.GetBytes(message);
                            stream.Write(data, 0, data.Length);
                        }
                    }
                }
            }
        }

        private Bitmap ResizeImage(Image image, int maxWidth, int maxHeight)
        {
            int width = image.Width;
            int height = image.Height;

            float scale = Math.Min((float)maxWidth / width, (float)maxHeight / height);
            int newWidth = (int)(width * scale);
            int newHeight = (int)(height * scale);

            Bitmap resized = new Bitmap(newWidth, newHeight);
            using (Graphics g = Graphics.FromImage(resized))
            {
                g.DrawImage(image, 0, 0, newWidth, newHeight);
            }

            return resized;
        }
        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            Disconnect();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Disconnect();
        }
    }
}
