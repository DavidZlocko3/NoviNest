﻿namespace Server
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtIP = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtPort = new TextBox();
            btnStart = new Button();
            listBoxMessages = new ListBox();
            txtRoomName = new TextBox();
            label4 = new Label();
            colorDialog1 = new ColorDialog();
            btnSetColor = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(42, 17);
            label1.Name = "label1";
            label1.Size = new Size(243, 25);
            label1.TabIndex = 0;
            label1.Text = "Postavi IP Adresu Chatrooma";
            // 
            // txtIP
            // 
            txtIP.Location = new Point(42, 53);
            txtIP.Name = "txtIP";
            txtIP.Size = new Size(202, 31);
            txtIP.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(442, 9);
            label2.Name = "label2";
            label2.Size = new Size(190, 65);
            label2.TabIndex = 2;
            label2.Text = "SERVER";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(42, 110);
            label3.Name = "label3";
            label3.Size = new Size(199, 25);
            label3.TabIndex = 3;
            label3.Text = "Postavi Port Chatrooma";
            // 
            // txtPort
            // 
            txtPort.Location = new Point(42, 149);
            txtPort.Name = "txtPort";
            txtPort.Size = new Size(202, 31);
            txtPort.TabIndex = 4;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(31, 281);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(204, 76);
            btnStart.TabIndex = 5;
            btnStart.Text = "Pokreni Chatroom";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // listBoxMessages
            // 
            listBoxMessages.FormattingEnabled = true;
            listBoxMessages.ItemHeight = 25;
            listBoxMessages.Location = new Point(509, 305);
            listBoxMessages.Name = "listBoxMessages";
            listBoxMessages.Size = new Size(563, 429);
            listBoxMessages.TabIndex = 6;
            // 
            // txtRoomName
            // 
            txtRoomName.Location = new Point(428, 119);
            txtRoomName.Name = "txtRoomName";
            txtRoomName.Size = new Size(263, 31);
            txtRoomName.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(427, 76);
            label4.Name = "label4";
            label4.Size = new Size(210, 25);
            label4.TabIndex = 8;
            label4.Text = "Postavi Naziv Chatrooma";
            label4.Click += label4_Click;
            // 
            // btnSetColor
            // 
            btnSetColor.Location = new Point(31, 449);
            btnSetColor.Name = "btnSetColor";
            btnSetColor.Size = new Size(197, 81);
            btnSetColor.TabIndex = 9;
            btnSetColor.Text = "Promijeni boju pozadine";
            btnSetColor.UseVisualStyleBackColor = true;
            btnSetColor.Click += btnSetColor_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1105, 772);
            Controls.Add(btnSetColor);
            Controls.Add(label4);
            Controls.Add(txtRoomName);
            Controls.Add(listBoxMessages);
            Controls.Add(btnStart);
            Controls.Add(txtPort);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtIP);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtIP;
        private Label label2;
        private Label label3;
        private TextBox txtPort;
        private Button btnStart;
        private ListBox listBoxMessages;
        private TextBox txtRoomName;
        private Label label4;
        private ColorDialog colorDialog1;
        private Button btnSetColor;
    }
}
