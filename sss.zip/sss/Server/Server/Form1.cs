﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Server
{
    public partial class Form1 : Form
    {
        private TcpListener listener;
        private List<TcpClient> clients = new List<TcpClient>();
        private bool isRunning = false;
        private string roomName = "Chatroom";
        private Dictionary<TcpClient, string> clientNames = new Dictionary<TcpClient, string>();
        private Dictionary<TcpClient, string> clientUsernames = new Dictionary<TcpClient, string>();
        public Form1()
        {
            InitializeComponent();
        }
        private void StartServer(IPAddress ip, int port)
        {
            listener = new TcpListener(ip, port);
            listener.Start();
            isRunning = true;
            AppendMessage($"Server listening on {ip}:{port}");

            Thread acceptThread = new Thread(() =>
            {
                while (isRunning)
                {
                    try
                    {
                        var client = listener.AcceptTcpClient();
                        clients.Add(client);
                        Thread clientThread = new Thread(() => HandleClient(client));
                        clientThread.IsBackground = true;
                        clientThread.Start();
                    }
                    catch { break; }
                }
            });

            acceptThread.IsBackground = true;
            acceptThread.Start();
        }
        private void HandleClient(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            string username = "";

            try
            {
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                if (bytesRead == 0) return;

                username = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();
                clientUsernames[client] = username;

                Broadcast($"[INFO] Dobrodošao {username}!");
                AppendMessage($"{username} se priključio.");
                UpdateUserList();

                while (isRunning)
                {
                    bytesRead = stream.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0) break;

                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    if (message.StartsWith("__IMG:"))
                    {
                        BroadcastRaw(buffer, bytesRead);
                    }
                    else
                    {
                        Broadcast(message);
                        AppendMessage(message);
                    }
                }
            }
            catch
            {
            }
            finally
            {
                if (clientUsernames.ContainsKey(client))
                {
                    string leftUser = clientUsernames[client];
                    Broadcast($"[INFO] Zbogom {leftUser}!");
                    AppendMessage($"{leftUser} je napustio sobu.");
                    clientUsernames.Remove(client);
                    UpdateUserList();
                }

                clients.Remove(client);
                client.Close();
            }
        }
        private void Broadcast(string message)
        {
            byte[] data = Encoding.UTF8.GetBytes(message + "\n");
            foreach (var client in clients)
            {
                try
                {
                    client.GetStream().Write(data, 0, data.Length);
                }
                catch { }
            }
        }
        private void BroadcastRaw(byte[] data, int length)
        {
            foreach (var client in clients)
            {
                try
                {
                    client.GetStream().Write(data, 0, length);
                }
                catch { }
            }
        }
        private void AppendMessage(string message)
        {
            Invoke(new Action(() =>
            {
                listBoxMessages.Items.Add(message);
            }));
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            if (!IPAddress.TryParse(txtIP.Text.Trim(), out IPAddress ipAddress))
            {
                MessageBox.Show("Nevažeća IP adresa.");
                return;
            }

            if (!int.TryParse(txtPort.Text.Trim(), out int port))
            {
                MessageBox.Show("Nevažeći port.");
                return;
            }

            StartServer(ipAddress, port);
            btnStart.Enabled = false;
            txtIP.Enabled = false;
            txtPort.Enabled = false;
            roomName = txtRoomName.Text.Trim();
            if (string.IsNullOrWhiteSpace(roomName)) roomName = "Chatroom";
        }
        private void UpdateUserList()
        {
            string userList = "[USERS]:" + string.Join(",", clientUsernames.Values);
            Broadcast(userList);
        }
        private void SendBackgroundColorToClients(string colorCode, List<string> targetUsernames)
        {
            string message = $"__SET_BG_COLOR:{colorCode}";

            byte[] data = Encoding.UTF8.GetBytes(message);
            foreach (var kvp in clientNames)
            {
                if (targetUsernames.Contains(kvp.Value))
                {
                    try
                    {
                        kvp.Key.GetStream().Write(data, 0, data.Length);
                    }
                    catch { }
                }
            }
        }
        private void btnSetColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                Color selected = colorDialog1.Color;
                string msg = $"__SETBG:{selected.ToArgb()}";
                Broadcast(msg);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
