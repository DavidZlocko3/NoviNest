﻿namespace Aplikacija_3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btnConnect = new Button();
            label4 = new Label();
            btnSend = new Button();
            txtUsername = new TextBox();
            txtIP = new TextBox();
            txtPort = new TextBox();
            txtMessage = new TextBox();
            listBoxChat = new ListBox();
            lblRoomName = new Label();
            btnDisconnect = new Button();
            lblUserCount = new Label();
            listBoxUsers = new ListBox();
            btnSendImage = new Button();
            pictureBoxImage = new PictureBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 25);
            label1.Name = "label1";
            label1.Size = new Size(170, 25);
            label1.TabIndex = 0;
            label1.Text = "Unesi Ime Korisnika:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 68);
            label2.Name = "label2";
            label2.Size = new Size(234, 25);
            label2.TabIndex = 1;
            label2.Text = "Unesi IP Adresu Chatrooma:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 111);
            label3.Name = "label3";
            label3.Size = new Size(190, 25);
            label3.TabIndex = 2;
            label3.Text = "Unesi Port Chatrooma:";
            label3.Click += label3_Click;
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(596, 25);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(233, 111);
            btnConnect.TabIndex = 3;
            btnConnect.Text = "Spoji se na chatroom";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(34, 295);
            label4.Name = "label4";
            label4.Size = new Size(119, 25);
            label4.TabIndex = 4;
            label4.Text = "Unesi Poruku:";
            // 
            // btnSend
            // 
            btnSend.Location = new Point(282, 266);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(149, 54);
            btnSend.TabIndex = 5;
            btnSend.Text = "Posalji";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSend_Click;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(228, 25);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(232, 31);
            txtUsername.TabIndex = 6;
            // 
            // txtIP
            // 
            txtIP.Location = new Point(282, 65);
            txtIP.Name = "txtIP";
            txtIP.Size = new Size(178, 31);
            txtIP.TabIndex = 7;
            // 
            // txtPort
            // 
            txtPort.Location = new Point(241, 111);
            txtPort.Name = "txtPort";
            txtPort.Size = new Size(219, 31);
            txtPort.TabIndex = 8;
            // 
            // txtMessage
            // 
            txtMessage.Location = new Point(34, 341);
            txtMessage.Multiline = true;
            txtMessage.Name = "txtMessage";
            txtMessage.Size = new Size(397, 102);
            txtMessage.TabIndex = 9;
            // 
            // listBoxChat
            // 
            listBoxChat.FormattingEnabled = true;
            listBoxChat.ItemHeight = 25;
            listBoxChat.Location = new Point(688, 337);
            listBoxChat.Name = "listBoxChat";
            listBoxChat.Size = new Size(550, 429);
            listBoxChat.TabIndex = 10;
            // 
            // lblRoomName
            // 
            lblRoomName.AutoSize = true;
            lblRoomName.Location = new Point(688, 295);
            lblRoomName.Name = "lblRoomName";
            lblRoomName.Size = new Size(52, 25);
            lblRoomName.TabIndex = 11;
            lblRoomName.Text = "Chat:";
            // 
            // btnDisconnect
            // 
            btnDisconnect.Enabled = false;
            btnDisconnect.Location = new Point(894, 25);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(233, 111);
            btnDisconnect.TabIndex = 12;
            btnDisconnect.Text = "Izadi Iz Chatrooma";
            btnDisconnect.UseVisualStyleBackColor = true;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // lblUserCount
            // 
            lblUserCount.AutoSize = true;
            lblUserCount.Location = new Point(54, 496);
            lblUserCount.Name = "lblUserCount";
            lblUserCount.Size = new Size(102, 25);
            lblUserCount.TabIndex = 13;
            lblUserCount.Text = "Korisnika: 0";
            // 
            // listBoxUsers
            // 
            listBoxUsers.FormattingEnabled = true;
            listBoxUsers.ItemHeight = 25;
            listBoxUsers.Location = new Point(54, 524);
            listBoxUsers.Name = "listBoxUsers";
            listBoxUsers.Size = new Size(329, 229);
            listBoxUsers.TabIndex = 14;
            // 
            // btnSendImage
            // 
            btnSendImage.Location = new Point(481, 341);
            btnSendImage.Name = "btnSendImage";
            btnSendImage.Size = new Size(155, 102);
            btnSendImage.TabIndex = 15;
            btnSendImage.Text = "Posalji Sliku";
            btnSendImage.UseVisualStyleBackColor = true;
            btnSendImage.Click += btnSendImage_Click;
            // 
            // pictureBoxImage
            // 
            pictureBoxImage.Location = new Point(417, 522);
            pictureBoxImage.Name = "pictureBoxImage";
            pictureBoxImage.Size = new Size(237, 231);
            pictureBoxImage.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxImage.TabIndex = 16;
            pictureBoxImage.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(418, 474);
            label5.Name = "label5";
            label5.Size = new Size(187, 25);
            label5.TabIndex = 17;
            label5.Text = "Zadnja Primljena Slika:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1259, 778);
            Controls.Add(label5);
            Controls.Add(pictureBoxImage);
            Controls.Add(btnSendImage);
            Controls.Add(listBoxUsers);
            Controls.Add(lblUserCount);
            Controls.Add(btnDisconnect);
            Controls.Add(lblRoomName);
            Controls.Add(listBoxChat);
            Controls.Add(txtMessage);
            Controls.Add(txtPort);
            Controls.Add(txtIP);
            Controls.Add(txtUsername);
            Controls.Add(btnSend);
            Controls.Add(label4);
            Controls.Add(btnConnect);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnConnect;
        private Label label4;
        private Button btnSend;
        private TextBox txtUsername;
        private TextBox txtIP;
        private TextBox txtPort;
        private TextBox txtMessage;
        private ListBox listBoxChat;
        private Label lblRoomName;
        private Button btnDisconnect;
        private Label lblUserCount;
        private ListBox listBoxUsers;
        private Button btnSendImage;
        private PictureBox pictureBoxImage;
        private Label label5;
    }
}
