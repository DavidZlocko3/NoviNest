﻿namespace Aplikacija
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxIPs = new ListBox();
            textBoxDodajIP = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtPortStart = new TextBox();
            txtPortEnd = new TextBox();
            label3 = new Label();
            label4 = new Label();
            btnDodajIP = new Button();
            btnStartScan = new Button();
            radioTCP = new RadioButton();
            radioUDP = new RadioButton();
            listBoxResults = new ListBox();
            SuspendLayout();
            // 
            // listBoxIPs
            // 
            listBoxIPs.FormattingEnabled = true;
            listBoxIPs.ItemHeight = 25;
            listBoxIPs.Location = new Point(67, 59);
            listBoxIPs.Name = "listBoxIPs";
            listBoxIPs.Size = new Size(348, 279);
            listBoxIPs.TabIndex = 0;
            // 
            // textBoxDodajIP
            // 
            textBoxDodajIP.Location = new Point(67, 402);
            textBoxDodajIP.Name = "textBoxDodajIP";
            textBoxDodajIP.Size = new Size(197, 31);
            textBoxDodajIP.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(63, 361);
            label1.Name = "label1";
            label1.Size = new Size(141, 25);
            label1.TabIndex = 2;
            label1.Text = "Dodaj IP Adresu";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(63, 9);
            label2.Name = "label2";
            label2.Size = new Size(87, 25);
            label2.TabIndex = 3;
            label2.Text = "IP Adrese";
            // 
            // txtPortStart
            // 
            txtPortStart.Location = new Point(480, 59);
            txtPortStart.Name = "txtPortStart";
            txtPortStart.Size = new Size(197, 31);
            txtPortStart.TabIndex = 4;
            // 
            // txtPortEnd
            // 
            txtPortEnd.Location = new Point(721, 59);
            txtPortEnd.Name = "txtPortEnd";
            txtPortEnd.Size = new Size(197, 31);
            txtPortEnd.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(480, 9);
            label3.Name = "label3";
            label3.Size = new Size(108, 25);
            label3.TabIndex = 6;
            label3.Text = "Pocetni port";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(721, 9);
            label4.Name = "label4";
            label4.Size = new Size(107, 25);
            label4.TabIndex = 7;
            label4.Text = "Zavrsni port";
            // 
            // btnDodajIP
            // 
            btnDodajIP.Location = new Point(67, 457);
            btnDodajIP.Name = "btnDodajIP";
            btnDodajIP.Size = new Size(214, 81);
            btnDodajIP.TabIndex = 8;
            btnDodajIP.Text = "Dodaj Adresu";
            btnDodajIP.UseVisualStyleBackColor = true;
            btnDodajIP.Click += btnDodajIP_Click;
            // 
            // btnStartScan
            // 
            btnStartScan.Location = new Point(602, 274);
            btnStartScan.Name = "btnStartScan";
            btnStartScan.Size = new Size(273, 112);
            btnStartScan.TabIndex = 9;
            btnStartScan.Text = "Zapocni";
            btnStartScan.UseVisualStyleBackColor = true;
            btnStartScan.Click += btnStartScan_Click;
            // 
            // radioTCP
            // 
            radioTCP.AutoSize = true;
            radioTCP.Location = new Point(497, 129);
            radioTCP.Name = "radioTCP";
            radioTCP.Size = new Size(66, 29);
            radioTCP.TabIndex = 10;
            radioTCP.TabStop = true;
            radioTCP.Text = "TCP";
            radioTCP.UseVisualStyleBackColor = true;
            // 
            // radioUDP
            // 
            radioUDP.AutoSize = true;
            radioUDP.Location = new Point(497, 178);
            radioUDP.Name = "radioUDP";
            radioUDP.Size = new Size(72, 29);
            radioUDP.TabIndex = 11;
            radioUDP.TabStop = true;
            radioUDP.Text = "UDP";
            radioUDP.UseVisualStyleBackColor = true;
            // 
            // listBoxResults
            // 
            listBoxResults.FormattingEnabled = true;
            listBoxResults.ItemHeight = 25;
            listBoxResults.Location = new Point(1074, 55);
            listBoxResults.Name = "listBoxResults";
            listBoxResults.Size = new Size(465, 354);
            listBoxResults.TabIndex = 12;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1632, 907);
            Controls.Add(listBoxResults);
            Controls.Add(radioUDP);
            Controls.Add(radioTCP);
            Controls.Add(btnStartScan);
            Controls.Add(btnDodajIP);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txtPortEnd);
            Controls.Add(txtPortStart);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxDodajIP);
            Controls.Add(listBoxIPs);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBoxIPs;
        private TextBox textBoxDodajIP;
        private Label label1;
        private Label label2;
        private TextBox txtPortStart;
        private TextBox txtPortEnd;
        private Label label3;
        private Label label4;
        private Button btnDodajIP;
        private Button btnStartScan;
        private RadioButton radioTCP;
        private RadioButton radioUDP;
        private ListBox listBoxResults;
    }
}
