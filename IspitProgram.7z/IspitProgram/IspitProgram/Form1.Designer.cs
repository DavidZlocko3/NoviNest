﻿namespace IspitProgram
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxIPs = new ListBox();
            label1 = new Label();
            txtPortStart = new TextBox();
            label2 = new Label();
            txtPortEnd = new TextBox();
            label3 = new Label();
            radioTCP = new RadioButton();
            radioUDP = new RadioButton();
            btnStartScan = new Button();
            listBoxResults = new ListBox();
            label4 = new Label();
            textBoxDodajIP = new TextBox();
            label5 = new Label();
            btnDodajIP = new Button();
            SuspendLayout();
            // 
            // listBoxIPs
            // 
            listBoxIPs.FormattingEnabled = true;
            listBoxIPs.ItemHeight = 25;
            listBoxIPs.Location = new Point(62, 38);
            listBoxIPs.Name = "listBoxIPs";
            listBoxIPs.Size = new Size(330, 329);
            listBoxIPs.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(62, 3);
            label1.Name = "label1";
            label1.Size = new Size(87, 25);
            label1.TabIndex = 1;
            label1.Text = "IP Adrese";
            // 
            // txtPortStart
            // 
            txtPortStart.Location = new Point(435, 38);
            txtPortStart.Name = "txtPortStart";
            txtPortStart.Size = new Size(150, 31);
            txtPortStart.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(435, 3);
            label2.Name = "label2";
            label2.Size = new Size(106, 25);
            label2.TabIndex = 3;
            label2.Text = "Pocetni Port";
            // 
            // txtPortEnd
            // 
            txtPortEnd.Location = new Point(626, 38);
            txtPortEnd.Name = "txtPortEnd";
            txtPortEnd.Size = new Size(150, 31);
            txtPortEnd.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(626, 3);
            label3.Name = "label3";
            label3.Size = new Size(105, 25);
            label3.TabIndex = 5;
            label3.Text = "Zavrsni Port";
            label3.Click += label3_Click;
            // 
            // radioTCP
            // 
            radioTCP.AutoSize = true;
            radioTCP.Location = new Point(442, 110);
            radioTCP.Name = "radioTCP";
            radioTCP.Size = new Size(66, 29);
            radioTCP.TabIndex = 6;
            radioTCP.TabStop = true;
            radioTCP.Text = "TCP";
            radioTCP.UseVisualStyleBackColor = true;
            // 
            // radioUDP
            // 
            radioUDP.AutoSize = true;
            radioUDP.Location = new Point(443, 156);
            radioUDP.Name = "radioUDP";
            radioUDP.Size = new Size(72, 29);
            radioUDP.TabIndex = 7;
            radioUDP.TabStop = true;
            radioUDP.Text = "UDP";
            radioUDP.UseVisualStyleBackColor = true;
            // 
            // btnStartScan
            // 
            btnStartScan.Location = new Point(496, 241);
            btnStartScan.Name = "btnStartScan";
            btnStartScan.Size = new Size(259, 126);
            btnStartScan.TabIndex = 8;
            btnStartScan.Text = "Pocni Program";
            btnStartScan.UseVisualStyleBackColor = true;
            btnStartScan.Click += btnStartScan_Click;
            // 
            // listBoxResults
            // 
            listBoxResults.FormattingEnabled = true;
            listBoxResults.ItemHeight = 25;
            listBoxResults.Location = new Point(984, 38);
            listBoxResults.Name = "listBoxResults";
            listBoxResults.Size = new Size(501, 329);
            listBoxResults.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(984, 3);
            label4.Name = "label4";
            label4.Size = new Size(74, 25);
            label4.TabIndex = 10;
            label4.Text = "Rezultat";
            // 
            // textBoxDodajIP
            // 
            textBoxDodajIP.Location = new Point(89, 473);
            textBoxDodajIP.Name = "textBoxDodajIP";
            textBoxDodajIP.Size = new Size(150, 31);
            textBoxDodajIP.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(89, 435);
            label5.Name = "label5";
            label5.Size = new Size(138, 25);
            label5.TabIndex = 12;
            label5.Text = "Dodaj IP adresu";
            // 
            // btnDodajIP
            // 
            btnDodajIP.Location = new Point(89, 510);
            btnDodajIP.Name = "btnDodajIP";
            btnDodajIP.Size = new Size(234, 110);
            btnDodajIP.TabIndex = 13;
            btnDodajIP.Text = "Dodaj IP ";
            btnDodajIP.UseVisualStyleBackColor = true;
            btnDodajIP.Click += btnDodajIP_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1669, 929);
            Controls.Add(btnDodajIP);
            Controls.Add(label5);
            Controls.Add(textBoxDodajIP);
            Controls.Add(label4);
            Controls.Add(listBoxResults);
            Controls.Add(btnStartScan);
            Controls.Add(radioUDP);
            Controls.Add(radioTCP);
            Controls.Add(label3);
            Controls.Add(txtPortEnd);
            Controls.Add(label2);
            Controls.Add(txtPortStart);
            Controls.Add(label1);
            Controls.Add(listBoxIPs);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBoxIPs;
        private Label label1;
        private TextBox txtPortStart;
        private Label label2;
        private TextBox txtPortEnd;
        private Label label3;
        private RadioButton radioTCP;
        private RadioButton radioUDP;
        private Button btnStartScan;
        private ListBox listBoxResults;
        private Label label4;
        private TextBox textBoxDodajIP;
        private Label label5;
        private Button btnDodajIP;
    }
}
