using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace SlikeServer
{
    public partial class Form1 : Form
    {
        private TcpListener listener;
        private Thread listenThread;
        public Form1()
        {
            InitializeComponent();
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            lblStatus.Text = "Server pokrenut...";

            listenThread = new Thread(StartServer);
            listenThread.IsBackground = true;
            listenThread.Start();
        }

        private void StartServer()
        {
            try
            {
                listener = new TcpListener(IPAddress.Any, 5000);
                listener.Start();

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();
                    Thread clientThread = new Thread(() => HandleClient(client));
                    clientThread.IsBackground = true;
                    clientThread.Start();
                }
            }
            catch (Exception ex)
            {
                Invoke(new Action(() => lblStatus.Text = "Gre�ka: " + ex.Message));
            }
        }

        private void HandleClient(TcpClient client)
        {
            try
            {
                using NetworkStream stream = client.GetStream();
                using MemoryStream ms = new MemoryStream();

                byte[] buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, bytesRead);
                }

                Image img = Image.FromStream(new MemoryStream(ms.ToArray()));
                Invoke(new Action(() =>
                {
                    pictureBoxReceived.Image = img;
                    lblStatus.Text = $"Primljena slika ({img.Width}x{img.Height})";
                }));
            }
            catch (Exception ex)
            {
                Invoke(new Action(() => lblStatus.Text = "Gre�ka kod klijenta: " + ex.Message));
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
