﻿namespace SlikeServer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblStatus = new Label();
            pictureBoxReceived = new PictureBox();
            btnStart = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBoxReceived).BeginInit();
            SuspendLayout();
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(65, 120);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(59, 25);
            lblStatus.TabIndex = 0;
            lblStatus.Text = "label1";
            // 
            // pictureBoxReceived
            // 
            pictureBoxReceived.Location = new Point(52, 179);
            pictureBoxReceived.Name = "pictureBoxReceived";
            pictureBoxReceived.Size = new Size(336, 278);
            pictureBoxReceived.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxReceived.TabIndex = 1;
            pictureBoxReceived.TabStop = false;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(429, 179);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(218, 112);
            btnStart.TabIndex = 2;
            btnStart.Text = "Pokreni Server";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1278, 702);
            Controls.Add(btnStart);
            Controls.Add(pictureBoxReceived);
            Controls.Add(lblStatus);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxReceived).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblStatus;
        private PictureBox pictureBoxReceived;
        private Button btnStart;
    }
}
