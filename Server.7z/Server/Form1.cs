﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;


namespace Server
{
    public partial class Form1 : Form
    {
        private TcpListener listener;
        private List<TcpClient> clients = new List<TcpClient>();
        private Dictionary<TcpClient, string> clientUsernames = new Dictionary<TcpClient, string>();
        private bool isRunning = false;
        private string roomName = "Chatroom";

        public Form1()
        {
            InitializeComponent();
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            if (!IPAddress.TryParse(txtIP.Text.Trim(), out IPAddress ipAddress))
            {
                MessageBox.Show("Nevažeća IP adresa.");
                return;
            }

            if (!int.TryParse(txtPort.Text.Trim(), out int port))
            {
                MessageBox.Show("Nevažeći port.");
                return;
            }

            roomName = txtRoomName.Text.Trim();
            if (string.IsNullOrWhiteSpace(roomName)) roomName = "Chatroom";

            listener = new TcpListener(ipAddress, port);
            listener.Start();
            isRunning = true;
            AppendMessage($"Server listening on {ipAddress}:{port}");

            Thread acceptThread = new Thread(() =>
            {
                while (isRunning)
                {
                    try
                    {
                        var client = listener.AcceptTcpClient();
                        clients.Add(client);
                        Thread clientThread = new Thread(() => HandleClient(client));
                        clientThread.IsBackground = true;
                        clientThread.Start();
                    }
                    catch { break; }
                }
            });

            acceptThread.IsBackground = true;
            acceptThread.Start();
            btnStart.Enabled = false;
        }

        private void HandleClient(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[8192];
            string username = "";

            try
            {
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                if (bytesRead == 0) return;

                username = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();
                clientUsernames[client] = username;

                Broadcast($"[INFO] Dobrodošao {username}!");
                AppendMessage($"{username} se priključio sobi.");
                UpdateUserList();
                SendRoomName(client);

                while (isRunning)
                {
                    bytesRead = stream.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0) break;

                    string msg = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    if (msg.StartsWith("__IMG:"))
                    {
                        BroadcastRaw(buffer, bytesRead);
                    }
                    else if (msg.StartsWith("__SETBG:"))
                    {
                        BroadcastRaw(buffer, bytesRead);
                    }
                    else
                    {
                        Broadcast(msg);
                        AppendMessage(msg);
                    }
                }
            }
            catch { }
            finally
            {
                if (clientUsernames.ContainsKey(client))
                {
                    string leftUser = clientUsernames[client];
                    Broadcast($"[INFO] Zbogom {leftUser}!");
                    AppendMessage($"{leftUser} je napustio sobu.");
                    clientUsernames.Remove(client);
                    UpdateUserList();
                }

                clients.Remove(client);
                client.Close();
            }
        }

        private void SendRoomName(TcpClient client)
        {
            string message = "ROOM|" + roomName;
            byte[] data = Encoding.UTF8.GetBytes(message + "\n");
            try
            {
                client.GetStream().Write(data, 0, data.Length);
            }
            catch { }
        }

        private void Broadcast(string message)
        {
            byte[] data = Encoding.UTF8.GetBytes(message + "\n");
            foreach (var client in clients)
            {
                try
                {
                    client.GetStream().Write(data, 0, data.Length);
                }
                catch { }
            }
        }

        private void BroadcastRaw(byte[] data, int length)
        {
            foreach (var client in clients)
            {
                try
                {
                    client.GetStream().Write(data, 0, length);
                }
                catch { }
            }
        }

        private void UpdateUserList()
        {
            string userList = "[USERS]:" + string.Join(",", clientUsernames.Values);
            Broadcast(userList);
        }

        private void AppendMessage(string message)
        {
            Invoke(new Action(() =>
            {
                listBoxMessages.Items.Add(message);
            }));
        }

        private void btnSetColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                Color selected = colorDialog1.Color;
                string msg = "__SETBG:" + selected.ToArgb();
                Broadcast(msg);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
